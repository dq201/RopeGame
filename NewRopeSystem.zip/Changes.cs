using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Changes : MonoBehaviour
{

    //private void TempHandleRopeUnwrap()
    //{
    //    if (ropePositions.Count <= 1)
    //    {
    //        wrapPointsLookup.Clear();
    //        return;
    //    }

    //    // 1
    //    var anchorIndex = ropePositions.Count - 2;
    //    // 2
    //    var hingeIndex = ropePositions.Count - 1;
    //    // 3
    //    var anchorPosition = ropePositions[anchorIndex];
    //    // 4
    //    var hingePosition = ropePositions[hingeIndex];
    //    // 5
    //    var hingeDir = hingePosition - anchorPosition;
    //    // 6
    //    //var hingeAngle = Vector2.Angle(anchorPosition, hingeDir);
    //    // 7
    //    var playerDir = playerPosition - hingePosition;
    //    // 8
    //    //var playerAngle = Vector2.Angle(anchorPosition, playerDir);

    //    if (!wrapPointsLookup.ContainsKey(hingePosition))
    //    {
    //        UnityEngine.Debug.LogError("We were not tracking hingePosition (" + hingePosition + ") in the look up dictionary.");
    //        return;
    //    }

    //    float angle = Vector2.SignedAngle(hingeDir, playerDir);

    //    //UnityEngine.Debug.Log("PlayerAngle: " + angle);

    //    if (angle < 0)
    //    {
    //        // 1
    //        if (wrapPointsLookup[hingePosition] > 0)
    //        {
    //            UnityEngine.Debug.Log("Unwrapping: " + ropePositions[hingeIndex] + " wrapPointlookUp: " + wrapPointsLookup[hingePosition] + " playerAngle:" + angle);
    //            wrapPointsLookup[hingePosition]--;
    //            UnwrapRopePosition(anchorIndex, hingeIndex);
    //            return;
    //        }
    //        Debug.Log("initial Angle < 0");
    //        // 2
    //        wrapPointsLookup[hingePosition]--; ;
    //    }
    //    else if (angle > 0)
    //    {
    //        // 3
    //        if (wrapPointsLookup[hingePosition] < 0)
    //        {
    //            UnityEngine.Debug.Log("Unwrapping: " + ropePositions[hingeIndex] + " wrapPointlookUp: " + wrapPointsLookup[hingePosition] + " playerAngle:" + angle);
    //            wrapPointsLookup[hingePosition]++;
    //            UnwrapRopePosition(anchorIndex, hingeIndex);
    //            return;
    //        }
    //        Debug.Log("initial Angle > 0");
    //        // 4
    //        wrapPointsLookup[hingePosition]++;
    //    }

    //}


    //private void UnwrapRopePosition(int anchorIndex, int hingeIndex)
    //{
    //    // 1
    //    var newAnchorPosition = ropePositions[anchorIndex];

    //    if (wrapPointsLookup[ropePositions[hingeIndex]] == 0)
    //        wrapPointsLookup.Remove(ropePositions[hingeIndex]);

    //    ropePositions.RemoveAt(hingeIndex);

    //    // 2
    //    ropeHingeAnchorRb.transform.position = newAnchorPosition;
    //    distanceSet = false;

    //    // Set new rope distance joint distance for anchor position if not yet set.
    //    if (distanceSet)
    //    {
    //        return;
    //    }
    //    ropeJoint.distance = Vector2.Distance(transform.position, newAnchorPosition);
    //    distanceSet = true;

    //}
}
